# Tetris background

A Pen created on CodePen.io. Original URL: [https://codepen.io/loktar00/pen/hGJBg](https://codepen.io/loktar00/pen/hGJBg).

Working on a background for my portfolio site revamp to match my business cards.

A bunch of Tetris games going on at once, you can control them all with the arrow keys to move and space or the up arrow to rotate... haha good luck.  AI is planned later, but I thought this looked pretty cool as is so far.
